import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'plan_model.dart';
import 'database_helper.dart';

class WeeklyPlanPage extends StatefulWidget {
  const WeeklyPlanPage({super.key});
  @override
  State<WeeklyPlanPage> createState() => _WeeklyPlanPageState();
}

class _WeeklyPlanPageState extends State<WeeklyPlanPage> {
  final db = DBHelper();
  late List<DateTime> _weekDates;

  @override
  void initState() {
    super.initState();
    _weekDates = _getCurrentWeek();
  }

  List<DateTime> _getCurrentWeek() {
    final now = DateTime.now();
    final monday = now.subtract(Duration(days: now.weekday - 1));
    return List.generate(7, (i) => monday.add(Duration(days: i)));
  }

  Future<List<StudySlot>> _loadSlots(String day) async {
    return await db.getSlotsByDay(day);
  }

  void _toggleCompleted(StudySlot slot) async {
    final updated = StudySlot(
      id: slot.id,
      day: slot.day,
      time: slot.time,
      subject: slot.subject,
      topic: slot.topic,
      completed: !slot.completed,
      comment: slot.comment,
    );
    await db.updateSlot(updated);
    setState(() {});
  }

  void _updateComment(StudySlot slot, String newComment) async {
    final updated = StudySlot(
      id: slot.id,
      day: slot.day,
      time: slot.time,
      subject: slot.subject,
      topic: slot.topic,
      completed: slot.completed,
      comment: newComment,
    );
    await db.updateSlot(updated);
    setState(() {});
  }

  Widget _buildSlotTile(StudySlot slot) {
    return ListTile(
      title: Text("${slot.time} • ${slot.subject}"),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(slot.topic),
          TextField(
            controller: TextEditingController(text: slot.comment),
            decoration: const InputDecoration(labelText: "Comment"),
            onSubmitted: (val) => _updateComment(slot, val),
          )
        ],
      ),
      trailing: Checkbox(
        value: slot.completed,
        onChanged: (_) => _toggleCompleted(slot),
      ),
    );
  }

  Widget _buildDayCard(DateTime date) {
    final day = DateFormat('EEEE').format(date);
    final dateStr = DateFormat('dd MMM').format(date);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ExpansionTile(
        title: Text("$day - $dateStr"),
        children: [
          FutureBuilder<List<StudySlot>>(
            future: _loadSlots(day),
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const CircularProgressIndicator();
              }
              final slots = snapshot.data ?? [];
              return Column(
                children: slots.map(_buildSlotTile).toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Weekly Study Plan")),
      body: ListView(
        padding: const EdgeInsets.all(8),
        children: _weekDates.map(_buildDayCard).toList(),
      ),
    );
  }
}
