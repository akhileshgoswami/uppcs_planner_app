class StudySlot {
  final int? id;
  final String day;
  final String time;
  final String subject;
  final String topic;
  final bool completed;
  final String comment;

  StudySlot({
    this.id,
    required this.day,
    required this.time,
    required this.subject,
    required this.topic,
    this.completed = false,
    this.comment = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'day': day,
        'time': time,
        'subject': subject,
        'topic': topic,
        'completed': completed ? 1 : 0,
        'comment': comment,
      };

  factory StudySlot.fromMap(Map<String, dynamic> map) => StudySlot(
        id: map['id'],
        day: map['day'],
        time: map['time'],
        subject: map['subject'],
        topic: map['topic'],
        completed: map['completed'] == 1,
        comment: map['comment'] ?? '',
      );
}
