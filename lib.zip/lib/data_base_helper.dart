import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uppcs_app/todo_model.dart';
import 'package:path/path.dart';
import 'package:device_info_plus/device_info_plus.dart';

class TodoDatabase {
  static final TodoDatabase instance = TodoDatabase._init();
  static Database? _database;

  TodoDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('todo.db');
    return _database!;
  }

  Future<Database> _initDB(String fileName) async {
    final backupDirPath = '/storage/emulated/0/UPPCS_Backup';
    final backupFilePath = '$backupDirPath/$fileName';
    final backupFile = File(backupFilePath);
    final backupDir = Directory(backupDirPath);

    await requestStoragePermission(); // Ensure permission

    // ✅ Create the folder if it doesn't exist
    if (!await backupDir.exists()) {
      try {
        await backupDir.create(recursive: true);
        debugPrint("📁 Created backup directory: $backupDirPath");
      } catch (e) {
        debugPrint("❌ Failed to create backup folder: $e");
      }
    }

    // ✅ Create empty DB if not exists
    if (!await backupFile.exists()) {
      try {
        // Just opening will auto-create an empty DB
        final db =
            await openDatabase(backupFilePath, version: 2, onCreate: _createDB);
        await db.close();
        debugPrint("🆕 Created new empty DB at: $backupFilePath");
      } catch (e) {
        debugPrint("❌ Failed to create DB: $e");
      }
    }

    // ✅ Always open DB from UPPCS_Backup path
    debugPrint("📂 Opening DB at: $backupFilePath");
    return await openDatabase(
      backupFilePath,
      version: 2,
      onCreate: _createDB,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE todos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject TEXT,
        task TEXT,
        subtask TEXT,
        isDone INTEGER,
        comment TEXT,
        doneDate TEXT
      )
    ''');
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      final columns = await db.rawQuery('PRAGMA table_info(todos)');
      final hasDoneDate = columns.any((col) => col['name'] == 'doneDate');
      if (!hasDoneDate) {
        await db.execute('ALTER TABLE todos ADD COLUMN doneDate TEXT');
      }
    }
  }

  Future<void> insertOrUpdate(TodoItem item) async {
    final db = await instance.database;
    final existing = await db.query(
      'todos',
      where: 'subject = ? AND task = ? AND subtask IS ?',
      whereArgs: [item.subject, item.task, item.subtask],
    );

    if (existing.isNotEmpty) {
      await db.update(
        'todos',
        item.toMap(),
        where: 'subject = ? AND task = ? AND subtask IS ?',
        whereArgs: [item.subject, item.task, item.subtask],
      );
    } else {
      await db.insert('todos', item.toMap());
    }
  }

  Future<List<TodoItem>> fetchAll() async {
    final db = await instance.database;
    final result = await db.query('todos');
    return result.map((map) => TodoItem.fromMap(map)).toList();
  }
}

extension TodoDatabaseBackup on TodoDatabase {
  Future<String> dbPath() async {
    final db = await database;
    return db.path;
  }

  Future<bool> requestStoragePermission() async {
    final info = await DeviceInfoPlugin().androidInfo;
    final sdk = info.version.sdkInt;

    if (sdk >= 30) {
      final status = await Permission.manageExternalStorage.request();
      if (status.isGranted) return true;

      if (status.isPermanentlyDenied) {
        await _showPermissionDialog();
        return false;
      }
    } else {
      final status = await Permission.storage.request();
      if (status.isGranted) return true;
    }

    Get.snackbar("Permission Denied", "Storage permission is required.",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.shade100,
        colorText: Colors.black);
    return false;
  }

  Future<void> _showPermissionDialog() async {
    await Get.defaultDialog(
      title: "Permission Needed",
      middleText:
          "Storage permission is permanently denied. Enable it in settings.",
      radius: 12,
      confirm: ElevatedButton.icon(
        icon: Icon(Icons.settings),
        label: Text("Open Settings"),
        style: ElevatedButton.styleFrom(backgroundColor: Colors.indigo),
        onPressed: () {
          Get.back();
          openAppSettings();
        },
      ),
      cancel: TextButton(
        onPressed: () => Get.back(),
        child: Text("Cancel"),
      ),
    );
  }
}
